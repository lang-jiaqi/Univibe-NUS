library global;
int userId = 1;
int coins = 0; // Global variable for coins
String username = 'ME'; // Global variable for username
int characterindex = 0;
String characterImage = 'assets/virtual_characters/peep-61.png';